
"""Validação segura das credenciais do Telegram para o JobRadar.

Não envia mensagem. Valida:
1) token -> getMe
2) chat_id -> getChat

Saída nunca imprime token, URL do bot ou dados sensíveis.
"""
from __future__ import annotations

import os
import sys
import requests

TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "")
CHAT_ID = os.getenv("TELEGRAM_CHAT_ID", "")

if not TOKEN or not CHAT_ID:
    print("ERRO: TELEGRAM_BOT_TOKEN e TELEGRAM_CHAT_ID precisam estar configurados.")
    sys.exit(2)

BASE = f"https://api.telegram.org/bot{TOKEN}"

def call(method: str, payload: dict | None = None) -> dict:
    try:
        r = requests.post(f"{BASE}/{method}", data=payload or {}, timeout=15)
        r.raise_for_status()
        data = r.json()
    except requests.HTTPError as exc:
        status = exc.response.status_code if exc.response is not None else "?"
        print(f"ERRO Telegram {method}: HTTP {status}.")
        sys.exit(3)
    except requests.RequestException as exc:
        print(f"ERRO Telegram {method}: {type(exc).__name__}.")
        sys.exit(4)
    if not data.get("ok"):
        print(f"ERRO Telegram {method}: API retornou ok=false.")
        sys.exit(5)
    return data

me = call("getMe").get("result", {})
chat = call("getChat", {"chat_id": CHAT_ID}).get("result", {})

print(f"Telegram OK — bot @{me.get('username', 'não informado')}")
print(f"Chat OK — tipo: {chat.get('type', 'não informado')}")
