# JobRadar — Etapa 3: Integração real

## Objetivo
Levar a versão consolidada das Etapas 1 e 2 para uma execução real:
GitHub Actions → fontes → filtros → banco → Telegram.

## Nesta versão
- Os três perfis podem ser executados pelo workflow: Brasil, Internacional e Comercial/Relacional.
- O banco `data/jobs.db` continua persistido entre execuções.
- A deduplicação por URL e por empresa+título continua ativa.
- O Telegram continua usando `TELEGRAM_BOT_TOKEN` e `TELEGRAM_CHAT_ID` como Secrets.
- Novo `verificar_telegram.py`: antes da busca, o workflow valida token e chat com `getMe` e `getChat`, sem enviar mensagem de teste e sem imprimir o token.
- Se as credenciais estiverem erradas, o workflow falha antes de iniciar uma busca, evitando um ciclo silenciosamente sem Telegram.
- Os testes continuam rodando separadamente em `.github/workflows/testes.yml`.

## Importante
A validação local não consegue provar o envio real ao Telegram porque depende dos Secrets do GitHub e do acesso externo à API. A primeira execução do workflow é o teste de ponta a ponta.

## Regras preservadas
Todas as regras aprovadas nas etapas anteriores permanecem: salário objetivo mínimo, CLT/PJ explícitos, vagas abertas, exclusão de banco de talentos, exclusão de qualquer reembolso/pagamento/curso obrigatório, congruência de remoto, fontes aprovadas, InfoJobs fora e distinção entre São Paulo capital e Estado de São Paulo.
