"""Enriquecimento conservador de uma vaga a partir da página pública.

Só preenche campos que conseguem ser encontrados no HTML/JSON-LD. Não faz
inferência de salário anual para mensal nem marca vaga como aberta quando a
página não diz isso.
"""
from __future__ import annotations

import html
import json
import re
from html.parser import HTMLParser

import requests

from core.eligibilidade import (
    analisar_incongruencia_remoto,
    detectar_banco_talentos,
    detectar_status,
    evidencias_remoto,
    extrair_candidatos,
    extrair_cnpj,
    extrair_prazo,
    extrair_regime,
    extrair_salario,
    sinais_fraude,
)
from core.logger import get_logger

logger = get_logger()


class _TextoHTML(HTMLParser):
    def __init__(self):
        super().__init__()
        self.partes: list[str] = []
        self._script = False
        self.jsonld: list[str] = []

    def handle_starttag(self, tag, attrs):
        if tag.lower() == "script":
            tipo = dict(attrs).get("type", "").lower()
            self._script = True
            if "ld+json" not in tipo:
                self._script = "outro"
            else:
                self._script = "jsonld"

    def handle_endtag(self, tag):
        if tag.lower() == "script":
            self._script = False

    def handle_data(self, data):
        if self._script == "jsonld":
            self.jsonld.append(data)
        elif self._script is False:
            d = data.strip()
            if d:
                self.partes.append(d)


def _extrair_html(url: str) -> tuple[str, list[dict]]:
    resposta = requests.get(
        url,
        timeout=12,
        headers={
            "User-Agent": (
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124 Safari/537.36"
            ),
            "Accept-Language": "pt-BR,pt;q=0.9,en;q=0.8",
        },
    )
    resposta.raise_for_status()
    parser = _TextoHTML()
    parser.feed(resposta.text)
    texto = html.unescape("\n".join(parser.partes))
    jsons = []
    for bruto in parser.jsonld:
        try:
            obj = json.loads(bruto)
            if isinstance(obj, list):
                jsons.extend(x for x in obj if isinstance(x, dict))
            elif isinstance(obj, dict):
                jsons.append(obj)
        except (ValueError, TypeError):
            continue
    return texto, jsons


def enriquecer_job(job) -> bool:
    """Tenta enriquecer uma vaga; retorna True se a página respondeu.

    Falha de rede não transforma a vaga em "encerrada". A decisão continua
    baseada apenas no que a fonte já informou.
    """
    try:
        texto, jsons = _extrair_html(job.link)
    except requests.RequestException:
        return False
    except Exception as e:
        logger.debug(f"Falha de parsing em {job.link}: {type(e).__name__}")
        return False

    if not texto and not jsons:
        return True

    dados = texto
    # JSON-LD JobPosting costuma conter description, salary, validThrough,
    # employmentType e jobLocation. Acrescentamos os valores ao texto para
    # reaproveitar os parsers sem criar uma segunda lógica por fonte.
    for obj in jsons:
        if str(obj.get("@type", "")).lower() == "jobposting":
            for chave in ("description", "salaryCurrency", "datePosted", "validThrough", "employmentType", "applicantLocationRequirements"):
                valor = obj.get(chave)
                if valor:
                    dados += "\n" + (json.dumps(valor, ensure_ascii=False) if isinstance(valor, (dict, list)) else str(valor))

    if not job.salario_texto:
        s = extrair_salario(dados)
        job.salario_minimo = s.minimo
        job.salario_maximo = s.maximo
        job.salario_periodicidade = s.periodicidade
        job.salario_texto = s.texto
    if not job.regime_contratacao:
        job.regime_contratacao = extrair_regime(dados)
    if not job.status_vaga or job.status_vaga == "nao_informado":
        job.status_vaga = detectar_status(dados)
    if job.candidatos_numero is None:
        job.candidatos_numero = extrair_candidatos(dados)
    if not job.prazo_candidatura:
        job.prazo_candidatura = extrair_prazo(dados)
    if not job.empresa_cnpj:
        job.empresa_cnpj = extrair_cnpj(dados)
    if not job.banco_talentos:
        job.banco_talentos = detectar_banco_talentos(dados)

    alertas, bloqueio = sinais_fraude(dados)
    job.sinais_alerta = list(dict.fromkeys((job.sinais_alerta or []) + alertas))
    job.bloqueio_fraude = job.bloqueio_fraude or bloqueio

    inc, motivos = analisar_incongruencia_remoto(job.modalidade, job.local, dados)
    job.incongruencia_remoto = job.incongruencia_remoto or inc
    job.sinais_alerta = list(dict.fromkeys((job.sinais_alerta or []) + motivos))
    if not job.evidencias_remoto:
        job.evidencias_remoto = evidencias_remoto(job.modalidade, job.local, dados)

    if not job.descricao:
        job.descricao = dados[:5000]
    if not job.texto_fonte:
        job.texto_fonte = dados[:12000]
    return True


def enriquecer_vagas(vagas: list, max_workers: int = 6) -> None:
    """Enriquece em paralelo apenas o que ainda está sem salário/status.

    O acesso é best-effort: não bloqueia o pipeline por erro de uma página.
    """
    from concurrent.futures import ThreadPoolExecutor, as_completed

    alvo = [
        v for v in vagas
        if v.salario_minimo is None or v.status_vaga in ("", "nao_informado")
    ]
    if not alvo:
        return
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = [executor.submit(enriquecer_job, v) for v in alvo]
        for f in as_completed(futures):
            try:
                f.result()
            except Exception as e:
                logger.debug(f"Enriquecimento ignorado: {type(e).__name__}")
