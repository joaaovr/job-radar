"""Regras objetivas de elegibilidade e sinais de risco do JobRadar.

A ideia deste módulo é separar "o anúncio parece interessante" de "há
evidência suficiente para enviar a vaga". Nada aqui inventa salário,
modalidade, prazo ou número de candidatos: quando a fonte não informa, o
campo fica ausente e a regra configurada pode rejeitar por falta de evidência.
"""
from __future__ import annotations

import html
import re
import unicodedata
from dataclasses import dataclass


def normalizar(texto: str) -> str:
    s = unicodedata.normalize("NFKD", (texto or "").lower())
    return "".join(c for c in s if not unicodedata.combining(c))


def _numero_br(valor: str) -> float:
    valor = (valor or "").strip().replace("R$", "").replace("BRL", "").strip()
    valor = re.sub(r"\s+", "", valor)
    if "," in valor and "." in valor:
        # 11.200,00 -> 11200.00
        if valor.rfind(",") > valor.rfind("."):
            valor = valor.replace(".", "").replace(",", ".")
        else:
            valor = valor.replace(",", "")
    elif "," in valor:
        esquerda, direita = valor.rsplit(",", 1)
        valor = esquerda.replace(",", "") + ("." + direita if len(direita) <= 2 else direita)
    elif "." in valor:
        esquerda, direita = valor.rsplit(".", 1)
        # 5.000 é milhar; 5.50 é decimal.
        valor = esquerda.replace(".", "") + ("." + direita if len(direita) <= 2 else direita)
    try:
        return float(valor)
    except ValueError:
        return 0.0


@dataclass
class ResultadoSalario:
    minimo: float | None = None
    maximo: float | None = None
    periodicidade: str = ""
    texto: str = ""


# Só considera um valor como salário quando existe linguagem de remuneração
# por perto. Isso evita confundir VA/VR/TotalPass/auxílio com salário.
_PADROES_SALARIO = [
    re.compile(
        r"(?:sal[aá]rio|remunera(?:ç|c)[aã]o|salary|compensation|gross monthly|"
        r"monthly salary|sal[aá]rio mensal)[^.\n]{0,100}?"
        r"(?:R\$\s*|BRL\s*)?(\d{1,3}(?:[.\s]\d{3})*(?:,\d{2})?|\d{3,6})"
        r"(?:\s*(?:-|a|to|até)\s*(?:R\$\s*|BRL\s*)?(\d{1,3}(?:[.\s]\d{3})*(?:,\d{2})?|\d{3,6}))?",
        re.I,
    ),
    re.compile(
        r"(?:R\$\s*|BRL\s*)(\d{1,3}(?:[.\s]\d{3})*(?:,\d{2})?|\d{3,6})"
        r"(?:\s*(?:-|a|to)\s*(?:R\$\s*|BRL\s*)?(\d{1,3}(?:[.\s]\d{3})*(?:,\d{2})?|\d{3,6}))?"
        r"\s*(?:\((?:gross\s+monthly|mensal)\)|(?:brl|r\$)?\s*(?:gross\s+)?(?:per\s+month|/m[eê]s|mensal))",
        re.I,
    ),
]

def extrair_salario(texto: str) -> ResultadoSalario:
    t = html.unescape(texto or "")
    # Priorizamos contexto mensal explícito. Não convertemos anual -> mensal:
    # isso seria uma estimativa e o usuário pediu dado objetivo.
    for padrao in _PADROES_SALARIO:
        for m in padrao.finditer(t):
            antes = t[max(0, m.start()-80):m.end()+120].lower()
            depois = t[m.end():m.end()+80].lower()
            contexto = normalizar(antes + " " + depois)
            mensal = any(x in contexto for x in (
                "mes", "mensal", "monthly", "per month", "/month", "/mes",
            ))
            if not mensal:
                continue
            minimo = _numero_br(m.group(1))
            maximo = _numero_br(m.group(2)) if m.group(2) else minimo
            if minimo <= 0:
                continue
            return ResultadoSalario(
                minimo=minimo,
                maximo=maximo,
                periodicidade="mensal",
                texto=m.group(0).strip(),
            )
    return ResultadoSalario()


def extrair_regime(texto: str) -> str:
    t = normalizar(texto)
    if re.search(r"\b(?:clt|efetivo\s*[-–—]?\s*clt)\b", t):
        return "CLT"
    if re.search(r"\b(?:pj|prestador(?:a)?\s+de\s+servicos|pessoa juridica)\b", t):
        return "PJ"
    return ""


_STATUS_FECHADO = (
    "esta vaga nao esta recebendo novos curriculos",
    "vaga encerrada",
    "vaga fechada",
    "candidaturas encerradas",
    "nao esta recebendo novos curriculos",
    "nao aceita mais candidaturas",
    "no longer accepting applications",
    "job is closed",
    "position has been filled",
    "vaga foi cancelada",
    "vaga cancelada",
    "vaga expirou",
    "vaga expirada",
    "expired",
)
_STATUS_ABERTO = (
    "candidate-se",
    "candidatar-se",
    "inscreva-se",
    "apply now",
    "apply",
    "enviar curriculo",
    "candidatura",
)


def detectar_status(texto: str) -> str:
    t = normalizar(texto)
    if any(p in t for p in _STATUS_FECHADO):
        return "encerrada"
    if any(p in t for p in _STATUS_ABERTO):
        return "aberta"
    return "nao_informado"


def detectar_banco_talentos(texto: str) -> bool:
    t = normalizar(texto)
    return any(p in t for p in (
        "banco de talentos",
        "talent pool",
        "future opportunities",
        "futuras oportunidades",
        "futuras contratacoes",
        "cadastre seu curriculo para futuras",
    ))


def extrair_candidatos(texto: str) -> int | None:
    t = normalizar(texto)
    padroes = (
        r"\b(\d[\d\.\s]*)\s*(?:candidatos?|candidaturas?)\b",
        r"\b(\d[\d\.\s]*)\s*applicants?\b",
    )
    for p in padroes:
        m = re.search(p, t, re.I)
        if m:
            try:
                return int(re.sub(r"\D", "", m.group(1)))
            except ValueError:
                pass
    return None


def extrair_cnpj(texto: str) -> str:
    m = re.search(r"\bCNPJ\s*:?\s*(\d{2}\.?\d{3}\.?\d{3}/?\d{4}-?\d{2})\b", texto or "", re.I)
    if not m:
        return ""
    digits = re.sub(r"\D", "", m.group(1))
    if len(digits) != 14:
        return m.group(1)
    return f"{digits[:2]}.{digits[2:5]}.{digits[5:8]}/{digits[8:12]}-{digits[12:]}"


def extrair_inicio(texto: str) -> str:
    t = texto or ""
    padroes = (
        r"(?i)(in[ií]cio\s+imediato|in[ií]cio\s+imediatamente)",
        r"(?i)(?:in[ií]cio|start(?:ing)?\s+date)[^\n.]{0,40}(\d{1,2}[/-]\d{1,2}(?:[/-]\d{2,4})?)",
        r"(?i)((?:come[cç]a|inicia)\s+(?:em|no dia)\s+\d{1,2}[/-]\d{1,2}(?:[/-]\d{2,4})?)",
    )
    for p in padroes:
        m = re.search(p, t)
        if m:
            return m.group(1).strip()
    return ""


def extrair_prazo(texto: str) -> str:
    t = texto or ""
    padroes = (
        r"(?i)(?:candidate-se|candidaturas?|apply|aplica(?:r|tion))[^.\n]{0,80}"
        r"(?:até|ate|by|until)\s*(\d{1,2}[/-]\d{1,2}(?:[/-]\d{2,4})?)",
        r"(?i)(?:prazo|deadline|encerramento)[^.\n]{0,60}"
        r"(\d{1,2}[/-]\d{1,2}(?:[/-]\d{2,4})?)",
    )
    for p in padroes:
        m = re.search(p, t)
        if m:
            return m.group(1)
    return ""


def sinais_fraude(texto: str) -> tuple[list[str], bool]:
    """Retorna (alertas, bloquear).

    Regra deliberadamente conservadora: qualquer menção a reembolso ou a
    curso/treinamento obrigatório é bloqueada, porque a usuária não quer
    gastar tempo com oportunidades que possam exigir desembolso, mesmo que o
    anúncio prometa devolver o valor depois. Também bloqueia exigências
    explícitas de taxa, PIX, depósito, compra ou pagamento pelo candidato.
    """
    t = normalizar(texto)
    alertas: list[str] = []

    reembolso = "reembolso" in t or "reembolsado" in t or "reembolsada" in t
    if reembolso:
        alertas.append("Reembolso mencionado — oportunidade bloqueada pela regra de segurança.")

    pagamento_candidato = any(p in t for p in (
        "taxa de inscricao",
        "taxa para participar",
        "taxa de cadastro",
        "taxa para candidatura",
        "taxa para candidatar",
        "pague para participar",
        "pagamento para participar",
        "pagamento do candidato",
        "candidato deve pagar",
        "candidato precisa pagar",
        "pix para",
        "deposito para",
        "depósito para",
        "compre o curso",
        "comprar o curso",
        "curso obrigatorio",
        "curso preparatorio obrigatorio",
        "treinamento obrigatorio",
        "treinamento preparatorio obrigatorio",
        "compra obrigatoria",
    ))
    if pagamento_candidato:
        alertas.append("Há exigência textual de taxa/pagamento/compra/curso ou treinamento obrigatório.")

    bloquear = reembolso or pagamento_candidato
    return alertas, bloquear


def analisar_incongruencia_remoto(modalidade: str, local: str, texto: str) -> tuple[bool, list[str]]:
    """Detecta contradição de modalidade sem tratar endereço da empresa como
    contradição.

    "Empresa localizada em São Paulo" não contradiz remoto. Já "mínimo 3
    dias no escritório" contradiz e bloqueia.
    """
    t = normalizar(texto)
    l = normalizar(local)
    remoto = normalizar(modalidade) in ("remoto", "remota") or any(
        p in normalizar(local + " " + texto[:2000]) for p in (
            "100% remoto", "totalmente remoto", "fully remote", "teletrabalho",
            "teletrabajo", "trabalho remoto", "work from home",
        )
    )
    if not remoto:
        return False, []

    contradicoes = (
        ("hibrido", "anúncio menciona modelo híbrido"),
        ("hybrid", "anúncio menciona modelo híbrido"),
        ("presencial", "anúncio menciona trabalho presencial"),
        ("on-site", "anúncio menciona trabalho on-site"),
        ("onsite", "anúncio menciona trabalho on-site"),
        ("minimum 1 day at office", "anúncio exige presença no escritório"),
        ("minimum 2 days at office", "anúncio exige presença no escritório"),
        ("minimum 3 days at office", "anúncio exige presença no escritório"),
        ("days in office", "anúncio exige dias no escritório"),
        ("dias no escritorio", "anúncio exige dias no escritório"),
        ("no escritorio", "anúncio exige presença no escritório"),
        ("commute to the office", "anúncio exige deslocamento ao escritório"),
    )
    achadas = [msg for termo, msg in contradicoes if termo in t]
    # Não penaliza apenas porque o local tem cidade/endereço.
    return bool(achadas), achadas


def evidencias_remoto(modalidade: str, local: str, texto: str) -> list[str]:
    t = normalizar((local or "") + " " + (texto or ""))
    evidencias = []
    mapa = (
        ("100% remoto", "100% remoto"),
        ("totalmente remoto", "totalmente remoto"),
        ("fully remote", "fully remote"),
        ("teletrabalho", "teletrabalho"),
        ("teletrabajo", "teletrabajo"),
        ("trabalho remoto", "trabalho remoto"),
        ("work from home", "work from home"),
        ("home office", "home office"),
        ("remote", "remote"),
        ("remoto", "remoto"),
    )
    for termo, exibicao in mapa:
        if termo in t and exibicao not in evidencias:
            evidencias.append(exibicao)
    if normalizar(modalidade) in ("remoto", "remota") and "modalidade da fonte" not in evidencias:
        evidencias.append("modalidade da fonte")
    return evidencias[:5]



_TERMOS_RESIDENCIA_CAPITAL_SP = (
    "residir em sao paulo", "residencia em sao paulo",
    "morar em sao paulo", "moradia em sao paulo",
    "residente em sao paulo", "resida em sao paulo",
)
_TERMOS_ESTADO_SP = (
    "estado de sao paulo", "estado de sp", "sao paulo sp",
)

def residencia_exige_capital_sp(texto: str) -> bool:
    t = normalizar(texto)
    if any(x in t for x in _TERMOS_ESTADO_SP):
        return False
    return any(x in t for x in _TERMOS_RESIDENCIA_CAPITAL_SP)

def criterio_objetivo(
    *,
    regime: str,
    salario_minimo: float | None,
    salario_periodicidade: str,
    status_vaga: str,
    banco_talentos: bool,
    alertas_fraude: list[str],
    bloqueio_fraude: bool,
    incongruencia_remoto: bool,
    exigir_salario: bool = True,
    bloquear_banco_talentos: bool = True,
    texto_localizacao: str = "",
) -> tuple[bool, list[str]]:
    motivos: list[str] = []
    if status_vaga == "encerrada":
        motivos.append("vaga explicitamente encerrada/sem novas candidaturas")
    if bloquear_banco_talentos and banco_talentos:
        motivos.append("banco de talentos/futuras oportunidades")
    if bloqueio_fraude:
        motivos.append("exigência de pagamento/taxa/compra pelo candidato")
    if incongruencia_remoto:
        motivos.append("incongruência entre remoto e presencial/híbrido")
    if residencia_exige_capital_sp(texto_localizacao):
        motivos.append("exigência de residência na cidade de São Paulo")
    if exigir_salario:
        if salario_minimo is None or salario_periodicidade != "mensal":
            motivos.append("salário fixo mensal não informado de forma objetiva")
        elif regime == "CLT" and salario_minimo < 2500:
            motivos.append("salário CLT abaixo de R$ 2.500 fixos")
        elif regime == "PJ" and salario_minimo < 3000:
            motivos.append("salário PJ abaixo de R$ 3.000 fixos")
        elif not regime:
            motivos.append("regime CLT/PJ não informado objetivamente")
        elif regime not in ("CLT", "PJ"):
            motivos.append("regime de contratação fora de CLT/PJ")
    return not motivos, motivos
