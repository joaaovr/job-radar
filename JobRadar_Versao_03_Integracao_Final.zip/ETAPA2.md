# JobRadar — Etapa 2 (revisada)

## Regras objetivas
- CLT: salário fixo mensal explicitamente informado e mínimo de R$ 2.500.
- PJ: salário fixo mensal explicitamente informado e mínimo de R$ 3.000.
- Salário ausente, "a combinar" ou sem periodicidade mensal objetiva: não passa.
- Regime CLT/PJ precisa estar explicitamente identificado quando o filtro de salário está ativo.
- Banco de talentos/futuras oportunidades: não passa.
- Vaga explicitamente encerrada, expirada, cancelada ou sem novas candidaturas: não passa.
- Qualquer menção a reembolso: não passa.
- Exigência textual de taxa, PIX, depósito, pagamento/compra pelo candidato ou curso/treinamento obrigatório: não passa.
- Remoto com incongruência explícita com presencial/híbrido ou exigência de presença: não passa.
- Informações como candidatos, CNPJ, prazo, início e evidências de remoto são exibidas apenas quando a fonte realmente informa.

## Fontes ativas no perfil Brasil
- LinkedIn
- Gupy
- Sólides
- Catho
- GeekHunter
- 99Jobs
- Senior
- JobLeads
- EMPREGARE
- WeWorkRemotely
- Remotar

## Fontes ativas no perfil Comercial / Relacional
- LinkedIn
- Gupy
- Sólides
- JobLeads
- EMPREGARE
- Remotar

## Fontes existentes no código, mas desligadas
- Indeed / Indeed Internacional — mantidos no código, mas atualmente desligados por problemas de resposta/bloqueio já documentados no projeto.
- Trampos — mantido no código, mas desligado por baixo rendimento/qualidade da busca.

## Fora do projeto
- InfoJobs: não está incluído e não deve ser adicionado.

## Remotar
Foi adicionado um scraper dedicado para a busca pública da Remotar. A fonte é tratada como remota no perfil Brasil/Comercial, mas o filtro objetivo continua valendo: salário, regime, status e demais regras ainda precisam passar.

## Testes
A suíte atual passou com **341 testes**.
