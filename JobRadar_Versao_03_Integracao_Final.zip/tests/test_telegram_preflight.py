
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def test_preflight_exige_secrets():
    env = os.environ.copy()
    env.pop("TELEGRAM_BOT_TOKEN", None)
    env.pop("TELEGRAM_CHAT_ID", None)
    r = subprocess.run(
        [sys.executable, str(ROOT / "verificar_telegram.py")],
        cwd=ROOT,
        env=env,
        capture_output=True,
        text=True,
    )
    assert r.returncode == 2
    assert "TELEGRAM_BOT_TOKEN" in r.stdout
    assert "TELEGRAM_CHAT_ID" in r.stdout
