from scrapers.vagas import BUSCA, VagasScraper


def test_url_busca_vagas_com_preserva_termo():
    assert BUSCA.format("analista%20de%20dados") == (
        "https://www.vagas.com.br/vagas-de-analista%20de%20dados?ordenar_por=mais_recentes"
    )


def test_link_vaga_vagas_com():
    assert VagasScraper._eh_link_vaga("/v2826564")
    assert VagasScraper._eh_link_vaga("https://www.vagas.com.br/v2826564")
    assert not VagasScraper._eh_link_vaga("/vagas-de-analista%20de%20dados")
    assert not VagasScraper._eh_link_vaga("/login-candidatos")


def test_modalidade_vagas_com():
    assert VagasScraper._modalidade("Analista de Dados\nGrupo Fleury\n100% Home Office") == "Remoto"
    assert VagasScraper._modalidade("Analista\nModelo híbrido\nSão Paulo / SP") == "Híbrido"
    assert VagasScraper._modalidade("Analista\nPresencial\nRecife / PE") == "Presencial"
