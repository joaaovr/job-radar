from __future__ import annotations

import re
from urllib.parse import quote

from playwright.sync_api import sync_playwright

from core.job import Job, _e_remoto, _normalizar
from core.logger import get_logger
from scrapers.base import BaseScraper

logger = get_logger()


def _slug(texto: str) -> str:
    s = _normalizar(texto)
    s = re.sub(r"[^a-z0-9]+", "-", s).strip("-")
    return s


class JobLeadsScraper(BaseScraper):
    """Busca no catálogo público brasileiro da JobLeads.

    A página de resultados expõe modalidade, local, faixa agregada e data em
    vários cards. O detalhe da vaga é deixado para o enriquecimento genérico
    do JobRadar quando o card não traz salário/status suficientes.
    """

    def __init__(self, termos_busca: list[str]):
        self.termos_busca = termos_busca

    def buscar_vagas(self) -> list[Job]:
        vagas: list[Job] = []
        for termo in self.termos_busca:
            url = f"https://www.jobleads.com/br/jobs/{_slug(termo)}-jobs"
            logger.info(f"[JobLeads] Buscando: {termo}")
            try:
                with sync_playwright() as p:
                    browser = p.chromium.launch(headless=True)
                    page = browser.new_page(
                        user_agent=(
                            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                            "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124 Safari/537.36"
                        )
                    )
                    try:
                        page.goto(url, timeout=60000, wait_until="domcontentloaded")
                        page.wait_for_timeout(1500)
                        links = page.locator("a[href*='/br/job/']").all()
                        vistos = set()
                        for a in links:
                            href = a.get_attribute("href")
                            if not href or href in vistos:
                                continue
                            titulo = a.inner_text().strip()
                            if not titulo or len(titulo) < 3:
                                continue
                            vistos.add(href)
                            card_text = a.locator("xpath=..").inner_text().strip()
                            linhas = [x.strip() for x in card_text.splitlines() if x.strip()]
                            idx = next((i for i, x in enumerate(linhas) if x == titulo), 0)
                            empresa = linhas[idx + 1] if idx + 1 < len(linhas) else "Não informado"
                            local = ""
                            for linha in linhas[idx + 2: idx + 7]:
                                if re.search(r"\b(?:Remote|Remoto|Teletrabalho|Híbrido|Hybrid|Presencial|On-site|On site)\b", linha, re.I):
                                    continue
                                if re.search(r"\b[A-Z]{2}\b", linha) or any(
                                    c in _normalizar(linha) for c in (
                                        "sao paulo", "brasilia", "rio de janeiro",
                                        "recife", "natal", "manaus", "joao pessoa",
                                        "campina grande", "caruaru", "maceio", "aracaju",
                                        "brasil",
                                    )
                                ):
                                    local = linha
                                    break
                            modalidade = ""
                            if re.search(r"\b(?:remote|remoto|teletrabalho)\b", card_text, re.I):
                                modalidade = "Remoto"
                            elif re.search(r"\b(?:hybrid|híbrido)\b", card_text, re.I):
                                modalidade = "Híbrido"
                            elif re.search(r"\b(?:on-site|on site|presencial)\b", card_text, re.I):
                                modalidade = "Presencial"
                            publicado = ""
                            m = re.search(r"(?i)(?:hoje|ontem|há\s+\d+\s+(?:dia|dias|semana|semanas|mês|meses)|\d+\s+days?\s+ago)", card_text)
                            if m:
                                publicado = m.group(0)
                            link = href if href.startswith("http") else "https://www.jobleads.com" + href
                            vagas.append(Job(
                                titulo=titulo,
                                empresa=empresa,
                                local=local or "Brasil",
                                link=link.split("?")[0],
                                site="JobLeads",
                                publicado_em=publicado,
                                modalidade=modalidade,
                                texto_fonte=card_text,
                            ))
                    finally:
                        browser.close()
            except Exception as e:
                logger.error(f"[JobLeads] Erro em '{termo}': {e}")
        logger.info(f"[JobLeads] {len(vagas)} vaga(s) encontrada(s)")
        return vagas
