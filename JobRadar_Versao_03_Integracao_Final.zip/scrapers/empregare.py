from __future__ import annotations

import re
from urllib.parse import quote

from playwright.sync_api import sync_playwright

from core.job import Job, _normalizar
from core.logger import get_logger
from scrapers.base import BaseScraper

logger = get_logger()


def _slug(texto: str) -> str:
    s = _normalizar(texto)
    s = re.sub(r"[^a-z0-9]+", "-", s).strip("-")
    return s


class EmpregareScraper(BaseScraper):
    """Busca a página pública de resultados da EMPREGARE.com.

    A plataforma oferece busca por cargo e filtros de modalidade, e as
    páginas individuais exibem explicitamente estado da vaga, regime e
    salário quando esses dados existem. O enriquecimento genérico completa
    o card quando necessário.
    """

    def __init__(self, termos_busca: list[str]):
        self.termos_busca = termos_busca

    def buscar_vagas(self) -> list[Job]:
        vagas: list[Job] = []
        for termo in self.termos_busca:
            url = f"https://www.empregare.com/pt-br/vagas-de-{_slug(termo)}"
            logger.info(f"[Empregare] Buscando: {termo}")
            try:
                with sync_playwright() as p:
                    browser = p.chromium.launch(headless=True)
                    page = browser.new_page(
                        user_agent=(
                            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                            "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124 Safari/537.36"
                        )
                    )
                    try:
                        page.goto(url, timeout=60000, wait_until="domcontentloaded")
                        page.wait_for_timeout(1500)
                        links = page.locator("a[href*='/pt-br/vaga-']").all()
                        vistos = set()
                        for a in links:
                            href = a.get_attribute("href")
                            if not href or href in vistos:
                                continue
                            titulo = a.inner_text().strip()
                            if not titulo or len(titulo) < 3:
                                continue
                            vistos.add(href)
                            card = a.locator("xpath=..")
                            card_text = card.inner_text().strip()
                            # Alguns cards são um nível acima do anchor.
                            if len(card_text) < len(titulo) + 20:
                                try:
                                    card_text = card.locator("xpath=..").inner_text().strip()
                                except Exception:
                                    pass
                            linhas = [x.strip() for x in card_text.splitlines() if x.strip()]
                            idx = next((i for i, x in enumerate(linhas) if x == titulo), 0)
                            empresa = ""
                            if idx > 0 and not re.search(r"\b(?:seg|ter|qua|qui|sex|sáb|dom)\b", linhas[idx-1], re.I):
                                empresa = linhas[idx-1]
                            local_match = re.search(r"([^\n,]+(?:\s+[^\n,]+)*),\s*[A-Z]{2},\s*BR\b", card_text)
                            local = local_match.group(1).strip() if local_match else ""
                            modalidade = ""
                            if re.search(r"(?i)(?:totalmente\s+remoto|remoto|home\s+office|teletrabalho)", card_text):
                                modalidade = "Remoto"
                            elif re.search(r"(?i)(?:híbrido|hybrid)", card_text):
                                modalidade = "Híbrido"
                            elif re.search(r"(?i)(?:presencial|on-site|onsite)", card_text):
                                modalidade = "Presencial"
                            link = href if href.startswith("http") else "https://www.empregare.com" + href
                            vagas.append(Job(
                                titulo=titulo,
                                empresa=empresa or "Não informado",
                                local=local or "Brasil",
                                link=link.split("?")[0],
                                site="Empregare",
                                publicado_em="",
                                modalidade=modalidade,
                                texto_fonte=card_text,
                            ))
                    finally:
                        browser.close()
            except Exception as e:
                logger.error(f"[Empregare] Erro em '{termo}': {e}")
        logger.info(f"[Empregare] {len(vagas)} vaga(s) encontrada(s)")
        return vagas
