from __future__ import annotations

import re
from urllib.parse import quote, urljoin

from playwright.sync_api import sync_playwright

from core.job import Job
from core.logger import get_logger
from scrapers.base import BaseScraper

logger = get_logger()

BASE = "https://remotar.com.br"
BUSCA = BASE + "/search/jobs?q={}"


class RemotarScraper(BaseScraper):
    """Coleta vagas públicas da Remotar.

    A Remotar é uma curadoria focada em vagas remotas e a página pública de
    busca aceita uma consulta por texto. O scraper é propositalmente
    conservador: só transforma links que parecem apontar para uma vaga em
    Job; não cria salário, regime, empresa ou status quando a página não os
    informa. O enriquecimento genérico do JobRadar consulta a página final
    quando possível.
    """

    def __init__(self, termos_busca: list[str]):
        self.termos_busca = termos_busca

    @staticmethod
    def _modalidade(texto: str) -> str:
        t = (texto or "").lower()
        if re.search(r"100%\s*remot|totalmente\s+remot|\bremot[oa]\b|home\s*office|teletrabalho", t):
            return "Remoto"
        if re.search(r"h[ií]brid|hybrid", t):
            return "Híbrido"
        if re.search(r"presencial|on[- ]?site|onsite", t):
            return "Presencial"
        return ""

    @staticmethod
    def _card_text(anchor) -> str:
        try:
            text = anchor.locator("xpath=..").inner_text().strip()
            if len(text) >= 30:
                return text
        except Exception:
            pass
        try:
            return anchor.locator("xpath=../..").inner_text().strip()
        except Exception:
            return anchor.inner_text().strip()

    def buscar_vagas(self) -> list[Job]:
        vagas: list[Job] = []
        vistos: set[str] = set()

        try:
            with sync_playwright() as p:
                browser = p.chromium.launch(headless=True)
                page = browser.new_page(
                    user_agent=(
                        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                        "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124 Safari/537.36"
                    )
                )
                try:
                    for termo in self.termos_busca:
                        url = BUSCA.format(quote(termo))
                        logger.info(f"[Remotar] Buscando: {termo}")
                        try:
                            page.goto(url, timeout=60000, wait_until="domcontentloaded")
                            page.wait_for_timeout(1200)

                            # A plataforma usa links próprios/remot.se para a
                            # candidatura. Também aceitamos /vaga e /job caso
                            # o formato interno mude.
                            links = page.locator(
                                'a[href*="remot.se/"], '
                                'a[href*="/vaga/"], '
                                'a[href*="/job/"]'
                            ).all()

                            for a in links:
                                href = a.get_attribute("href")
                                titulo = a.inner_text().strip()
                                if not href or not titulo or len(titulo) < 3:
                                    continue
                                if href.startswith("#") or href.startswith("mailto:"):
                                    continue
                                link = urljoin(BASE, href).split("?")[0]
                                if link in vistos:
                                    continue
                                # Evita capturar navegação, páginas de empresa ou
                                # links genéricos que por acaso contenham /job/.
                                if not ("remot.se/" in link or "/vaga/" in link or "/job/" in link):
                                    continue

                                card = self._card_text(a)
                                if not card:
                                    card = titulo
                                modalidade = self._modalidade(card)

                                linhas = [x.strip() for x in card.splitlines() if x.strip()]
                                empresa = ""
                                idx = next((i for i, x in enumerate(linhas) if x == titulo), -1)
                                if idx >= 0:
                                    for candidato in linhas[idx + 1: idx + 4]:
                                        if candidato != titulo and len(candidato) <= 120:
                                            empresa = candidato
                                            break

                                vistos.add(link)
                                vagas.append(Job(
                                    titulo=titulo,
                                    empresa=empresa or "Não informado",
                                    local="Brasil",
                                    link=link,
                                    site="Remotar",
                                    publicado_em="",
                                    modalidade=modalidade or "Remoto",
                                    texto_fonte=card,
                                ))
                        except Exception as e:
                            logger.error(f"[Remotar] Erro em '{termo}': {type(e).__name__}")
                finally:
                    browser.close()
        except Exception as e:
            logger.error(f"[Remotar] Falha ao iniciar navegador: {type(e).__name__}")

        logger.info(f"[Remotar] {len(vagas)} vaga(s) encontrada(s)")
        return vagas
