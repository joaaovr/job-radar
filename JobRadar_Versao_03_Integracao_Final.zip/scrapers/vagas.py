from __future__ import annotations

import re
from urllib.parse import quote, urljoin, urlparse

from playwright.sync_api import sync_playwright

from core.eligibilidade import detectar_banco_talentos, detectar_status, evidencias_remoto
from core.job import Job
from core.logger import get_logger
from scrapers.base import BaseScraper

logger = get_logger()

BASE = "https://www.vagas.com.br"
BUSCA = BASE + "/vagas-de-{}?ordenar_por=mais_recentes"


class VagasScraper(BaseScraper):
    """Coleta vagas públicas do Vagas.com.

    A pesquisa pública usa URLs no formato /vagas-de-<termo>. A listagem já
    expõe título, empresa, nível, localização, modalidade quando declarada e
    data; a página individual é deixada para o enriquecimento genérico, que
    busca salário, regime, status, prazo, candidatos, CNPJ e sinais de risco.
    """

    def __init__(self, termos_busca: list[str]):
        self.termos_busca = termos_busca

    @staticmethod
    def _eh_link_vaga(href: str | None) -> bool:
        if not href:
            return False
        path = urlparse(urljoin(BASE, href)).path.rstrip("/")
        return bool(re.fullmatch(r"/v\d+", path))

    @staticmethod
    def _texto_card(anchor) -> str:
        # A estrutura do Vagas.com mudou algumas vezes. Em vez de depender de
        # uma única classe CSS, sobe alguns níveis e escolhe o primeiro bloco
        # que tenha contexto suficiente para representar o card.
        try:
            for nivel in range(1, 6):
                bloco = anchor.locator("xpath=" + "../" * (nivel - 1) + "..").inner_text().strip()
                if len(bloco) >= 60:
                    return bloco
        except Exception:
            pass
        try:
            return anchor.inner_text().strip()
        except Exception:
            return ""

    @staticmethod
    def _modalidade(texto: str) -> str:
        t = (texto or "").lower()
        if re.search(r"100%\s*home\s*office|100%\s*remot|totalmente\s+remot|fully\s+remote|teletrabalho|trabalho\s+remoto", t):
            return "Remoto"
        if re.search(r"home\s*office", t):
            # No Vagas.com "Home Office" pode aparecer como parte da
            # classificação "empresa e home office"; ainda é uma modalidade
            # compatível com o filtro e a análise de incongruência será feita
            # na página completa.
            return "Remoto"
        if re.search(r"h[ií]brido|hybrid", t):
            return "Híbrido"
        if re.search(r"presencial|on[- ]?site|onsite", t):
            return "Presencial"
        return ""

    @staticmethod
    def _empresa(texto: str, titulo: str) -> str:
        linhas = [x.strip() for x in (texto or "").splitlines() if x.strip()]
        if titulo in linhas:
            i = linhas.index(titulo)
            for candidato in linhas[i + 1 : i + 4]:
                if candidato == titulo:
                    continue
                if re.search(r"(?:j[uú]nior|pleno|s[eê]nior|trainee|auxiliar|t[eé]cnico|supervis[aã]o|coordena[cç][aã]o|ger[eê]ncia)", candidato, re.I):
                    continue
                if "/" in candidato and len(candidato) < 80:
                    continue
                if re.search(r"descri[cç][aã]o|100%\s*home|a empresa aceita|ontem|hoje|h[aá]\s+\d+", candidato, re.I):
                    continue
                if len(candidato) <= 120:
                    return candidato
        return "Não informado"

    @staticmethod
    def _local(texto: str) -> str:
        linhas = [x.strip() for x in (texto or "").splitlines() if x.strip()]
        for linha in linhas:
            if re.search(r"(?:/\s*[A-Z]{2}\b|\b[A-Z]{2}\s*$)", linha) and len(linha) <= 100:
                return linha
            if re.search(r"100%\s*home\s*office|home\s*office|remoto|h[ií]brido|presencial", linha, re.I) and len(linha) <= 100:
                return linha
        return "Não informado"

    @staticmethod
    def _publicado(texto: str) -> str:
        linhas = [x.strip() for x in (texto or "").splitlines() if x.strip()]
        for linha in reversed(linhas):
            if re.fullmatch(r"(?:hoje|ontem|h[aá]\s+\d+\s+(?:dia|dias|semana|semanas|m[eê]s|meses|ano|anos))", linha, re.I):
                return linha
            if re.fullmatch(r"\d{1,2}/\d{1,2}/\d{2,4}", linha):
                return linha
        return ""

    def _buscar_termo(self, termo: str) -> list[Job]:
        vagas: list[Job] = []
        vistos: set[str] = set()
        url = BUSCA.format(quote(termo, safe=""))
        logger.info(f"[Vagas.com] Buscando: {termo}")

        with sync_playwright() as p:
            browser = p.chromium.launch(headless=True)
            page = browser.new_page(
                user_agent=(
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                    "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124 Safari/537.36"
                ),
                locale="pt-BR",
            )
            try:
                page.goto(url, timeout=60000, wait_until="domcontentloaded")
                page.wait_for_timeout(1200)

                anchors = page.locator('a[href^="/v"]')
                total = anchors.count()
                for i in range(total):
                    try:
                        a = anchors.nth(i)
                        href = a.get_attribute("href")
                        if not self._eh_link_vaga(href):
                            continue
                        link = urljoin(BASE, href).split("?")[0]
                        if link in vistos:
                            continue
                        titulo = a.inner_text().strip()
                        if not titulo or len(titulo) < 3:
                            continue
                        texto = self._texto_card(a)
                        modalidade = self._modalidade(texto)
                        local = self._local(texto)
                        empresa = self._empresa(texto, titulo)
                        publicado = self._publicado(texto)

                        # A presença na página pública de resultados é uma
                        # evidência de que a oportunidade está sendo listada;
                        # o enriquecimento da página individual ainda pode
                        # substituir isso por "encerrada" se a fonte disser
                        # explicitamente que não aceita mais candidaturas.
                        status = detectar_status(texto)
                        if status == "nao_informado":
                            status = "aberta"

                        banco = detectar_banco_talentos(texto)
                        ev = evidencias_remoto(modalidade, local, texto)

                        vistos.add(link)
                        vagas.append(
                            Job(
                                titulo=titulo,
                                empresa=empresa,
                                local=local,
                                link=link,
                                site="Vagas.com",
                                publicado_em=publicado,
                                modalidade=modalidade,
                                status_vaga=status,
                                banco_talentos=banco,
                                evidencias_remoto=ev,
                                texto_fonte=texto,
                            )
                        )
                    except Exception as e:
                        logger.debug(f"[Vagas.com] Erro no card: {type(e).__name__}")
                        continue
            except Exception as e:
                logger.error(f"[Vagas.com] Erro ao buscar '{termo}': {type(e).__name__}")
            finally:
                browser.close()

        return vagas

    def buscar_vagas(self) -> list[Job]:
        vagas: list[Job] = []
        for termo in self.termos_busca:
            vagas.extend(self._buscar_termo(termo))
        logger.info(f"[Vagas.com] {len(vagas)} vaga(s) encontrada(s) no total")
        return vagas
